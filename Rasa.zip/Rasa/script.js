$(document).ready(() => {
    $(".chat-btn").click(() => {
        $("#main").slideToggle("slow")
    })
})

